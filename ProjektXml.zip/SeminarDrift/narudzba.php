<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $ime = $_POST["ime"];
  $prezime = $_POST["prezime"];
  $email = $_POST["email"];
  $adresa = $_POST["adresa"];

  $xmlFile = "narudzbaa.xml";

  if (file_exists($xmlFile)) {
    $xml = new DOMDocument();
    $xml->preserveWhiteSpace = false;
    $xml->formatOutput = true;
    $xml->load($xmlFile);

    $narudzbe = $xml->getElementsByTagName("narudzba");
    $posljednjaNarudzba = $narudzbe->item($narudzbe->length - 1);

    $narudzba = $xml->createElement("narudzba");
    $narudzba->appendChild($xml->createElement("ime", $ime));
    $narudzba->appendChild($xml->createElement("prezime", $prezime));
    $narudzba->appendChild($xml->createElement("email", $email));
    $narudzba->appendChild($xml->createElement("adresa", $adresa));

    $xml->documentElement->appendChild($narudzba);
  } else {
    $xml = new DOMDocument();
    $xml->formatOutput = true;

    $narudzba = $xml->createElement("narudzba");
    $xml->appendChild($narudzba);

    $narudzba->appendChild($xml->createElement("ime", $ime));
    $narudzba->appendChild($xml->createElement("prezime", $prezime));
    $narudzba->appendChild($xml->createElement("email", $email));
    $narudzba->appendChild($xml->createElement("adresa", $adresa));
  }

  $xml->save($xmlFile);

  header('Location: Uspjesno.html');
}
?>
